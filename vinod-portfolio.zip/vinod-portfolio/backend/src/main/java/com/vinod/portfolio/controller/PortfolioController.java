package com.vinod.portfolio.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class PortfolioController {

    // ── Contact Form ──────────────────────────────────────────────
    @PostMapping("/contact")
    public ResponseEntity<Map<String, String>> contact(@RequestBody Map<String, String> body) {
        String name    = body.getOrDefault("name", "");
        String email   = body.getOrDefault("email", "");
        String message = body.getOrDefault("message", "");

        if (name.isBlank() || email.isBlank() || message.isBlank()) {
            return ResponseEntity.badRequest()
                .body(Map.of("status", "error", "msg", "All fields are required."));
        }
        // TODO: wire up JavaMail / SendGrid to actually send email
        System.out.printf("📬 New message from %s <%s>: %s%n", name, email, message);
        return ResponseEntity.ok(Map.of("status", "ok", "msg", "Message received! I'll get back to you soon."));
    }

    // ── Profile / About data ──────────────────────────────────────
    @GetMapping("/about")
    public ResponseEntity<Map<String, Object>> about() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("name",     "Vinod");
        data.put("role",     "Computer Science Student & Aspiring Developer");
        data.put("location", "Bengaluru, India");
        data.put("college",  "B.E. Computer Science — 2025");
        data.put("bio",      "I love building cool things with code. Currently open to internships and fresher roles.");
        data.put("skills",   List.of(
            Map.of("name","Python",             "pct",85, "color","#7c6fe0"),
            Map.of("name","JavaScript / React", "pct",75, "color","#0fd4a0"),
            Map.of("name","HTML / CSS",         "pct",90, "color","#ff6b5b"),
            Map.of("name","SQL / Databases",    "pct",70, "color","#ffbe3d"),
            Map.of("name","Machine Learning",   "pct",65, "color","#f06de0"),
            Map.of("name","Java",               "pct",78, "color","#7c6fe0"),
            Map.of("name","Git & Linux",        "pct",80, "color","#0fd4a0")
        ));
        data.put("projects", List.of(
            Map.of("title","AI Chatbot",      "desc","College FAQ bot using Python & OpenAI API",
                   "tags",List.of("Python","OpenAI","Flask"),   "emoji","🤖", "color","#7c6fe0"),
            Map.of("title","E-Commerce UI",   "desc","React shopping site with cart & filters",
                   "tags",List.of("React","CSS","JavaScript"),  "emoji","🛒", "color","#0fd4a0"),
            Map.of("title","Marks Analyser",  "desc","CSV marks data + matplotlib visual reports",
                   "tags",List.of("Python","Pandas","Matplotlib"),"emoji","📊","color","#ff6b5b"),
            Map.of("title","Java Portfolio",  "desc","This very portfolio — Spring Boot + HTML/CSS",
                   "tags",List.of("Java","Spring Boot","CSS"),  "emoji","☕", "color","#ffbe3d")
        ));
        return ResponseEntity.ok(data);
    }

    // ── AI Image Generation (calls Pollinations.ai — free, no key) ─
    @GetMapping("/generate-image")
    public ResponseEntity<Map<String, String>> generateImage(
            @RequestParam(defaultValue = "futuristic developer workspace colorful neon dark") String prompt) {

        // Pollinations.ai: free, no API key, returns image URL directly
        String encodedPrompt = prompt.replace(" ", "%20");
        String imageUrl = "https://image.pollinations.ai/prompt/" + encodedPrompt
                          + "?width=800&height=400&nologo=true&seed=" + new Random().nextInt(9999);

        return ResponseEntity.ok(Map.of(
            "status", "ok",
            "url",    imageUrl,
            "prompt", prompt
        ));
    }
}
