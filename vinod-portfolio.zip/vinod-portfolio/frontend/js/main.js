// ── CONFIG ───────────────────────────────────────────────────────
const API = 'http://localhost:8080/api';

// ── CUSTOM CURSOR ────────────────────────────────────────────────
const cursor = document.getElementById('cursor');
const trail  = document.getElementById('cursor-trail');
document.addEventListener('mousemove', e => {
  cursor.style.left = (e.clientX - 6) + 'px';
  cursor.style.top  = (e.clientY - 6) + 'px';
  trail.style.left  = (e.clientX - 18) + 'px';
  trail.style.top   = (e.clientY - 18) + 'px';
});
document.querySelectorAll('button,a,.proj-card,.skill-card,.acard,.clink').forEach(el => {
  el.addEventListener('mouseenter', () => cursor.style.transform = 'scale(2.5)');
  el.addEventListener('mouseleave', () => cursor.style.transform = 'scale(1)');
});

// ── PARTICLE CANVAS ──────────────────────────────────────────────
(function initParticles() {
  const canvas = document.getElementById('particles');
  const ctx    = canvas.getContext('2d');
  let W, H, dots = [];

  const COLORS = ['#7c6fe0','#0fd4a0','#ff6b5b','#ffbe3d','#f06de0'];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  // Create dots
  for (let i = 0; i < 90; i++) {
    dots.push({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.5 + 0.4,
      vx: (Math.random() - 0.5) * 0.35,
      vy: (Math.random() - 0.5) * 0.35,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      alpha: Math.random() * 0.5 + 0.2
    });
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    dots.forEach(d => {
      d.x += d.vx; d.y += d.vy;
      if (d.x < 0) d.x = W; if (d.x > W) d.x = 0;
      if (d.y < 0) d.y = H; if (d.y > H) d.y = 0;

      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
      ctx.fillStyle = d.color + Math.floor(d.alpha * 255).toString(16).padStart(2,'0');
      ctx.fill();
    });

    // connect nearby dots
    for (let i = 0; i < dots.length; i++) {
      for (let j = i + 1; j < dots.length; j++) {
        const dx = dots[i].x - dots[j].x;
        const dy = dots[i].y - dots[j].y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 110) {
          ctx.beginPath();
          ctx.moveTo(dots[i].x, dots[i].y);
          ctx.lineTo(dots[j].x, dots[j].y);
          ctx.strokeStyle = `rgba(124,111,224,${0.12 * (1 - dist/110)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  }
  draw();
})();

// ── SCROLL REVEAL ────────────────────────────────────────────────
const revealObs = new IntersectionObserver((entries) => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => e.target.classList.add('visible'), i * 90);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

// ── ACTIVE NAV ───────────────────────────────────────────────────
const sections  = document.querySelectorAll('section');
const navLinks  = document.querySelectorAll('.nav-link');
window.addEventListener('scroll', () => {
  let cur = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 130) cur = s.id;
  });
  navLinks.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + cur));
});

// ── HAMBURGER MENU ───────────────────────────────────────────────
document.getElementById('hamburger').addEventListener('click', () => {
  document.querySelector('.nav-links').classList.toggle('open');
});

// ── SCROLL HELPER ────────────────────────────────────────────────
function scrollTo(id) {
  document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
}

// ── LOAD DATA FROM JAVA API ──────────────────────────────────────
async function loadPortfolioData() {
  try {
    const res  = await fetch(`${API}/about`);
    const data = await res.json();
    renderSkills(data.skills);
    renderProjects(data.projects);
  } catch (err) {
    // API not running — use fallback data
    console.warn('Java API not reachable — using fallback data');
    renderSkills([
      { name:'Java',               pct:78, color:'#7c6fe0' },
      { name:'Python',             pct:85, color:'#0fd4a0' },
      { name:'JavaScript/React',   pct:75, color:'#ff6b5b' },
      { name:'HTML/CSS',           pct:90, color:'#ffbe3d' },
      { name:'SQL',                pct:70, color:'#f06de0' },
      { name:'Git & Linux',        pct:80, color:'#7c6fe0' },
    ]);
    renderProjects([
      { title:'AI Chatbot',     desc:'College FAQ bot using Python & OpenAI API',        tags:['Python','OpenAI','Flask'],    emoji:'🤖', color:'#7c6fe0' },
      { title:'E-Commerce UI',  desc:'React shopping site with cart & filters',          tags:['React','CSS','JS'],           emoji:'🛒', color:'#0fd4a0' },
      { title:'Marks Analyser', desc:'CSV marks data + matplotlib visual reports',       tags:['Python','Pandas','Matplotlib'],emoji:'📊', color:'#ff6b5b' },
      { title:'Java Portfolio', desc:'This portfolio — Spring Boot + HTML/CSS/JS',       tags:['Java','Spring Boot','CSS'],   emoji:'☕', color:'#ffbe3d' },
    ]);
  }
}

function renderSkills(skills) {
  const grid = document.getElementById('skillsGrid');
  grid.innerHTML = skills.map((s, i) => `
    <div class="skill-card reveal" style="animation-delay:${i*0.08}s">
      <div class="skill-top">
        <div class="skill-info">
          <div class="skill-dot" style="background:${s.color}"></div>
          <span class="skill-name-lbl">${s.name}</span>
        </div>
        <span class="skill-pct-lbl">${s.pct}%</span>
      </div>
      <div class="bar-bg">
        <div class="bar-fill" style="background:${s.color}" data-w="${s.pct}"></div>
      </div>
    </div>
  `).join('');

  // re-observe new cards
  document.querySelectorAll('.skill-card.reveal').forEach(el => revealObs.observe(el));

  // animate bars when skills section visible
  const skillsSection = document.getElementById('skills');
  new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      document.querySelectorAll('.bar-fill').forEach(bar => {
        bar.style.width = bar.dataset.w + '%';
      });
    }
  }, { threshold: 0.25 }).observe(skillsSection);
}

function renderProjects(projects) {
  const grid = document.getElementById('projGrid');
  const colors = ['#7c6fe0','#0fd4a0','#ff6b5b','#ffbe3d'];
  grid.innerHTML = projects.map((p, i) => `
    <div class="proj-card reveal" style="animation-delay:${i*0.1}s; border-top:2px solid ${p.color}">
      <div class="proj-thumb" style="background:${p.color}18">
        <div class="proj-thumb-grid"></div>
        <div class="proj-emoji">${p.emoji}</div>
      </div>
      <div class="proj-body">
        <span class="proj-badge" style="background:${p.color}22;color:${p.color}">${p.tags[0]}</span>
        <h3>${p.title}</h3>
        <p>${p.desc}</p>
        <div class="proj-tags">${p.tags.map(t=>`<span class="ptag">${t}</span>`).join('')}</div>
        <div class="proj-arrow">view project →</div>
      </div>
    </div>
  `).join('');
  document.querySelectorAll('.proj-card.reveal').forEach(el => revealObs.observe(el));
}

// ── AI IMAGE GENERATOR ───────────────────────────────────────────
async function generateImage() {
  const prompt = document.getElementById('imgPrompt').value.trim();
  if (!prompt) return;

  const btn    = document.getElementById('genBtn');
  const result = document.getElementById('aiResult');

  btn.disabled = true;
  btn.textContent = 'generating...';
  result.innerHTML = `
    <div class="ai-loading">
      <div class="spinner"></div>
      <span>generating your image — takes ~5s...</span>
    </div>`;

  try {
    // Try Java API first; fallback to Pollinations directly
    let imageUrl;
    try {
      const res  = await fetch(`${API}/generate-image?prompt=${encodeURIComponent(prompt)}`);
      const data = await res.json();
      imageUrl   = data.url;
    } catch {
      // Fallback: call Pollinations directly from browser
      const seed = Math.floor(Math.random() * 99999);
      imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=800&height=400&nologo=true&seed=${seed}`;
    }

    const img = new Image();
    img.onload = () => {
      result.innerHTML = '';
      result.appendChild(img);
      img.style.cssText = 'width:100%;display:block;border-radius:10px;animation:fadeUp 0.5s ease';
    };
    img.onerror = () => {
      result.innerHTML = `<div class="ai-placeholder"><p style="color:#ff6b5b">Could not load image. Try a different prompt!</p></div>`;
    };
    img.src = imageUrl;
  } catch (err) {
    result.innerHTML = `<div class="ai-placeholder"><p style="color:#ff6b5b">Error: ${err.message}</p></div>`;
  } finally {
    btn.disabled = false;
    btn.textContent = 'generate ✦';
  }
}

// Enter key triggers generate
document.getElementById('imgPrompt').addEventListener('keydown', e => {
  if (e.key === 'Enter') generateImage();
});

// ── HERO & ABOUT AI IMAGES ───────────────────────────────────────
async function loadHeroImage() {
  const img    = document.getElementById('heroImg');
  const loader = document.getElementById('heroLoader');
  const seed   = Math.floor(Math.random() * 99999);
  const prompt = encodeURIComponent('futuristic developer workspace colorful neon dark cyberpunk bengaluru');
  img.src = `https://image.pollinations.ai/prompt/${prompt}?width=900&height=260&nologo=true&seed=${seed}`;
  img.onload  = () => { loader.style.display='none'; img.classList.remove('hidden'); };
  img.onerror = () => { loader.style.display='none'; };
}

async function loadAboutImage() {
  const img    = document.getElementById('aboutImg');
  const loader = document.getElementById('aboutLoader');
  const seed   = Math.floor(Math.random() * 99999);
  const prompt = encodeURIComponent('indian student developer at computer desk colorful bokeh lights portrait');
  img.src = `https://image.pollinations.ai/prompt/${prompt}?width=600&height=400&nologo=true&seed=${seed}`;
  img.onload  = () => { loader.style.display='none'; img.classList.remove('hidden'); };
  img.onerror = () => { loader.style.display='none'; };
}

// ── CONTACT FORM ─────────────────────────────────────────────────
async function sendContact() {
  const name  = document.getElementById('cName').value.trim();
  const email = document.getElementById('cEmail').value.trim();
  const msg   = document.getElementById('cMsg').value.trim();
  const btn   = document.getElementById('submitBtn');
  const out   = document.getElementById('formMsg');

  if (!name || !email || !msg) {
    out.textContent = 'please fill all fields.';
    out.className = 'form-msg err';
    return;
  }
  btn.disabled = true;
  btn.textContent = 'sending...';
  out.textContent = '';

  try {
    const res  = await fetch(`${API}/contact`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ name, email, message: msg })
    });
    const data = await res.json();
    out.textContent = data.msg;
    out.className   = data.status === 'ok' ? 'form-msg ok' : 'form-msg err';
    if (data.status === 'ok') {
      document.getElementById('cName').value  = '';
      document.getElementById('cEmail').value = '';
      document.getElementById('cMsg').value   = '';
      btn.textContent = 'sent! ✓';
      btn.style.background = 'linear-gradient(135deg,#0fd4a0,#085041)';
      setTimeout(() => { btn.textContent='send message ✦'; btn.style.background=''; btn.disabled=false; }, 3000);
      return;
    }
  } catch {
    // API not running — simulate success
    out.textContent = 'message received! (start the Java server to enable real sending)';
    out.className   = 'form-msg ok';
    btn.textContent = 'sent! ✓';
    btn.style.background = 'linear-gradient(135deg,#0fd4a0,#085041)';
    setTimeout(() => { btn.textContent='send message ✦'; btn.style.background=''; }, 3000);
  }
  btn.disabled = false;
}

// ── INIT ─────────────────────────────────────────────────────────
loadPortfolioData();
loadHeroImage();
loadAboutImage();
