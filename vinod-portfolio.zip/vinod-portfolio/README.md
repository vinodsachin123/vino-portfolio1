# Vinod Portfolio — Java + HTML + CSS + AI Images

## Project Structure
```
vinod-portfolio/
├── backend/                  ← Java Spring Boot
│   ├── pom.xml
│   └── src/main/java/com/vinod/portfolio/
│       ├── PortfolioApplication.java
│       └── controller/PortfolioController.java
└── frontend/                 ← HTML + CSS + JS
    ├── index.html
    ├── css/style.css
    └── js/main.js
```

## Features / Enna irukku
- 5 sections: Hero, About, Skills, Projects, Contact
- Animated particle background (connected dots)
- Custom cursor with trail effect
- Scroll reveal animations on all sections
- Animated skill progress bars
- **AI Image Generator** — type any prompt, get AI image (Pollinations.ai)
- Auto-generated hero banner & about image on load
- Java Spring Boot REST API (/api/about, /api/contact, /api/generate-image)
- Works even without Java backend (fallback data built-in)

## How to Run — Epdi run pannurathu

### Option A: Frontend only (no Java needed)
Just double-click `frontend/index.html` in browser.
AI images work directly! Skills & projects use fallback data.

### Option B: Full Stack (Java + Frontend)

**Step 1 — Java backend start pannunga:**
```bash
cd backend
mvn spring-boot:run
```
Backend runs at: http://localhost:8080

**Step 2 — Frontend open pannunga:**
Open `frontend/index.html` in browser.
Or use Live Server extension in VS Code.

## API Endpoints
| Method | URL                              | Description          |
|--------|----------------------------------|----------------------|
| GET    | /api/about                       | portfolio data       |
| POST   | /api/contact                     | contact form         |
| GET    | /api/generate-image?prompt=...   | AI image URL         |

## Customize — Ungal details maathunga
In `frontend/js/main.js`, fallback data la:
- Your name, college, skills, projects update pannunga

In `backend/.../PortfolioController.java`:
- `about()` method la real data add pannunga
- `contact()` method la JavaMail add pannunga (optional)

## Requirements
- Java 17+
- Maven 3.8+
- Any modern browser
